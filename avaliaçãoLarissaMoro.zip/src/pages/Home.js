import '../App.css';
import React, { useState } from "react"
import HeaderWeather from '../components/HeaderWeather';
import ItemBox from '../components/ItemBox';
import BoxMessage from '../components/BoxMessage';
import axios from 'axios';
export default function Home() {
    const [weather, setWeathers] = useState([]);
    const [cityInput, setCityInput] = useState('');
    const [stateInput, setStateInput] = useState('');
    const [error, setError] = useState('');
    const key = "3efe3ae0"

    function getWeather(city, state) {
        if (city.length > 0 && state.length > 0) {
            axios.get(`https://api.hgbrasil.com/weather?format=json-cors&key=${key}&city_name=${cityInput},${stateInput}`)
                .then(res => {
                    setWeathers(res.data.results)
                    setError('')
                }).catch((e) => {
                    console.log('Houve algum erro: ', e)
                    setError('Houve algum problema com a api, verifique os dados enviados e a sua chave')
                })
        } else {
            setError('ATENÇÃO! Informe todos os dados')
        }
    }

    return (
        <div className="row">
            <div className="weather_form row">
                <div className="col-md-12 weather_form-header">
                    <h2>Consulta de temperatura</h2>
                    <small>{error}</small>
                </div>
                <form onSubmit={(info) => {
                    info.preventDefault();
                    getWeather(cityInput, stateInput)
                }} className="row">
                    <div className=" col-md-4">
                        <input type='text' placeholder='Campinas' className='form-control'
                            onChange={(e) => {
                                setCityInput(e.target.value)
                            }}
                        />
                        {cityInput.length === 0
                            ? 'Preencha o campo de cidade'
                            : ''
                        }<br />
                    </div>
                    <div className=" col-md-4">
                        <input type='text' placeholder='SP' className='form-control'
                            onChange={(e) => {
                                setStateInput(e.target.value)
                            }}
                        />
                        {stateInput.length === 0
                            ? 'Preencha o campo do estado'
                            : ''
                        }
                    </div>
                    <div className=" col-md-4">
                        <input className='form-control' type='submit' value='Procurar' />
                    </div>
                </form>

            </div>

            <div className="weather_content">
                {typeof weather === "undefined" || weather.length <= 0 ? (

                    <BoxMessage title="Realize a pesquisa no formulario acima" message="" />
                ) : (
                    <>
                        <HeaderWeather weather={weather} />
                        <h2>Próximos dias</h2>
                        <ItemBox itens={weather.forecast} />
                    </>
                )}
            </div>
        </div>


    );
}

