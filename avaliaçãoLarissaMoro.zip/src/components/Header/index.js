import React from 'react'
import './index.css'
export default function Header() {
  return (
    <>
      <div className="col-md-12 weather_header">
        <div className='text-center'>Weather App</div>
      </div>
    </>
  )
}