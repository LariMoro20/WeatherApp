# Avaliação de Frameworks web

## Rodar aplicação

Na pasta do projeto rodar:

`npm install`

Rodar a aplicação:
`npm start`
Estará em  [http://localhost:3000](http://localhost:3000)
